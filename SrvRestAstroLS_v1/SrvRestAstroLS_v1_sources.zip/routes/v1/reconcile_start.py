# -*- coding: utf-8 -*-
# SrvRestAstroLS_v1/routes/v1/reconcile_start.py

from __future__ import annotations

import asyncio
import math
import traceback
from datetime import timedelta
from pathlib import Path
from typing import Any, Optional, Tuple

from litestar import post
from litestar.response import Response

import pandas as pd

from .agui_notify import emit
from urllib.parse import urlparse


# =========================
# Helpers (IO)
# =========================
def _from_file_uri(uri: str) -> Path:
    """
    Convierte file://... en Path usable.
    Permite también rutas planas por compat.
    """
    if uri and uri.startswith("file://"):
        return Path(urlparse(uri).path)
    return Path(uri)


# =========================
# Loaders estandarizados
# =========================
def _clean_money(s: pd.Series) -> pd.Series:
    """Normaliza importes (AR): quita símbolos, maneja paréntesis negativo, puntos miles, comas decimales."""
    s = s.astype(str).fillna("")
    neg = s.str.contains(r"\(", regex=True)
    s = (
        s.str.replace(r"[^\d,\.\-\(\)]", "", regex=True)
         .str.replace(r"[\(\)]", "", regex=True)
         .str.replace(".", "", regex=False)  # quita miles
         .str.replace(",", ".", regex=False)  # coma -> punto
    )
    out = pd.to_numeric(s, errors="coerce")
    out = out.fillna(0.0)
    out.loc[neg] = -out.loc[neg].abs()
    return out


def _load_pilaga(path: Path) -> pd.DataFrame:
    """
    Lee PILAGA (hoja 'Resumen cuenta bancaria' o la primera),
    con columnas: fecha, documento, ingreso, egreso -> monto (ingreso - egreso).
    Devuelve DF con columnas estandarizadas: ['fecha','monto','documento','origen']
    """
    xls = pd.ExcelFile(str(path), engine="openpyxl")
    sheet = next((n for n in xls.sheet_names if str(n).strip().lower() == "resumen cuenta bancaria"), xls.sheet_names[0])
    raw = pd.read_excel(xls, sheet_name=sheet)

    # Intento directo por nombres que nos pasaste
    cols_map_options = [
        # Caso que nos compartiste
        {"fecha": "Resumen cuenta bancaria", "doc": "Unnamed: 1", "ing": "Unnamed: 8", "egr": "Unnamed: 9"},
        # Variante frecuente (por si cambia el nombre de la primera col)
        {"fecha": raw.columns[0], "doc": "Unnamed: 1", "ing": "Unnamed: 8", "egr": "Unnamed: 9"},
    ]

    fecha_col = doc_col = ing_col = egr_col = None
    for m in cols_map_options:
        try:
            _ = raw[m["fecha"]]  # fuerza KeyError si no existe
            _ = raw[m["doc"]]
            _ = raw[m["ing"]]
            _ = raw[m["egr"]]
            fecha_col, doc_col, ing_col, egr_col = m["fecha"], m["doc"], m["ing"], m["egr"]
            break
        except Exception:
            continue

    if not fecha_col:
        # Heurística mínima: tomar 1ra col como fecha, y las dos últimas como ingreso/egreso si son numéricas
        fecha_col = raw.columns[0]
        last2 = raw.columns[-2:]
        ing_col, egr_col = last2[0], last2[1]
        # documento como la 2da si existe
        doc_col = raw.columns[1] if len(raw.columns) > 1 else raw.columns[0]

    df = pd.DataFrame({
        "fecha": pd.to_datetime(raw[fecha_col], dayfirst=True, errors="coerce"),
        "documento": raw[doc_col].astype(str),
        "ingreso": pd.to_numeric(raw[ing_col], errors="coerce"),
        "egreso": pd.to_numeric(raw[egr_col], errors="coerce"),
    })
    df["monto"] = df["ingreso"].fillna(0) - df["egreso"].fillna(0)
    df = df.dropna(subset=["fecha"])
    df = df[df["monto"].notna()]
    df = df[df["monto"] != 0]
    df = df.loc[:, ["fecha", "monto", "documento"]].copy()
    df["origen"] = "PILAGA"
    return df.reset_index(drop=True)


def _find_header_row_with_fecha(df: pd.DataFrame, scan_rows: int = 50) -> Optional[int]:
    """
    Busca la fila de encabezado en la que, además de 'Fecha', aparecen otras
    columnas esperables del extracto (Comprobante, Concepto, Importe, etc.).
    Esto evita falsos positivos en filas informativas previas al detalle.
    """
    expected = {"FECHA", "COMPROBANTE", "CONCEPTO/COD.OP.", "CONCEPTO", "DETALLE",
                "DESCRIPCION", "DESCRIPCIÓN", "IMPORTE", "MONTO", "SALDO"}
    best_idx: Optional[int] = None
    best_score = -1

    for i in range(min(len(df), scan_rows)):
        vals = [str(x).strip().upper() for x in df.iloc[i].tolist()]
        if not any(vals):
            continue
        has_fecha = any(v == "FECHA" or v.startswith("FECHA") for v in vals)
        score = sum(1 for v in vals if v in expected)
        if has_fecha:
            score += 1  # favorecemos filas que tengan FECHA explícito

        if score > best_score and (has_fecha or score >= 2):
            best_idx = i
            best_score = score
            if best_score >= 4:  # heurística: suficiente evidencia
                break

    return best_idx


def _load_extracto(path: Path) -> pd.DataFrame:
    """
    Lee EXTRACTO bancario (hoja 'principal' o primera).
    Detecta encabezado (fila con 'Fecha'), normaliza monto.
    Devuelve DF con columnas estandarizadas: ['fecha','monto','documento','origen']
    """
    xls = pd.ExcelFile(str(path), engine="openpyxl")
    sheet = next((n for n in xls.sheet_names if str(n).strip().lower() == "principal"), xls.sheet_names[0])
    raw = pd.read_excel(xls, sheet_name=sheet, header=None)

    hdr = _find_header_row_with_fecha(raw)
    if hdr is None:
        hdr = 0

    headers = [str(x or "").strip() for x in raw.iloc[hdr].tolist()]
    df = raw.iloc[hdr + 1:].copy()
    df.columns = headers
    df = df.dropna(how="all")

    # Candidatos típicos (según tu análisis)
    fecha_col = next((c for c in df.columns if str(c).strip().upper() == "FECHA"), df.columns[0])
    # Importe suele estar en 'Unnamed: 4' o 'IMPORTE' etc. Probamos:
    cand_importe = [c for c in df.columns if str(c).strip().upper() in ("IMPORTE", "IMPORTE EN $", "MONTO")]
    importe_col = cand_importe[0] if cand_importe else (df.columns[4] if len(df.columns) > 4 else df.columns[-1])

    # Documento/descripcion (opcional; si no está, igual seguimos)
    cand_doc = [c for c in df.columns if str(c).strip().upper() in ("COMPROBANTE", "DESCRIPCIÓN", "DETALLE", "DESCRIPCION")]
    doc_col = cand_doc[0] if cand_doc else (df.columns[2] if len(df.columns) > 2 else df.columns[0])

    def _col_as_series(col_name: Any) -> pd.Series:
        col = df[col_name]
        if isinstance(col, pd.DataFrame):
            return col.iloc[:, 0]
        return col

    fecha_data = _col_as_series(fecha_col)
    doc_data = _col_as_series(doc_col)
    importe_data = _col_as_series(importe_col)

    out = pd.DataFrame({
        "fecha": pd.to_datetime(fecha_data, dayfirst=True, errors="coerce"),
        "documento": doc_data.astype(str),
        "monto": _clean_money(importe_data),
    })
    out = out.dropna(subset=["fecha"])
    out = out[out["monto"] != 0]
    out["origen"] = "EXTRACTO"
    return out.reset_index(drop=True)


# =========================
# Matching (± ventana días)
# =========================
def _match_one_to_one_by_amount_and_date_window(
    df_p: pd.DataFrame,
    df_b: pd.DataFrame,
    days_window: int
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Empareja uno-a-uno por monto idéntico (redondeado a 2) y |fecha_p - fecha_b| <= days_window.
    Retorna: pairs, sobrantes_pilaga, sobrantes_banco
    """
    p = df_p.copy()
    b = df_b.copy()

    p["monto_r"] = p["monto"].round(2)
    b["monto_r"] = b["monto"].round(2)

    # Join por monto
    merged = p.merge(b, on="monto_r", suffixes=("_p", "_b"))
    # Ventana de fechas
    merged["date_diff_days"] = (merged["fecha_p"] - merged["fecha_b"]).abs().dt.days
    merged = merged[merged["date_diff_days"] <= abs(int(days_window))]

    # Greedy: quedarnos con el match más cercano por monto/fecha
    merged = merged.sort_values(["monto_r", "date_diff_days"])
    merged = merged.drop_duplicates(subset=["fecha_p", "monto_r", "documento_p"], keep="first")
    merged = merged.drop_duplicates(subset=["fecha_b", "monto_r", "documento_b"], keep="first")

    # Restos
    used_p = set(merged.index.get_level_values(0))  # cuidado: merged index default
    # Es mejor trackear por combinaciones:
    keyp = set(zip(merged["fecha_p"], merged["monto_r"], merged["documento_p"]))
    keyb = set(zip(merged["fecha_b"], merged["monto_r"], merged["documento_b"]))

    kp = set(zip(p["fecha"], p["monto_r"], p["documento"]))
    kb = set(zip(b["fecha"], b["monto_r"], b["documento"]))

    no_p = kp - keyp
    no_b = kb - keyb

    sobrantes_p = p[p.apply(lambda r: (r["fecha"], r["monto_r"], r["documento"]) in no_p, axis=1)]
    sobrantes_b = b[b.apply(lambda r: (r["fecha"], r["monto_r"], r["documento"]) in no_b, axis=1)]

    return merged.reset_index(drop=True), sobrantes_p.reset_index(drop=True), sobrantes_b.reset_index(drop=True)


# =========================
# API Route
# =========================
@post("/api/reconcile/start")
async def reconcile_start(request: Any) -> Response:
    """
    FORM multipart o x-www-form-urlencoded:
      - threadId (opcional): para SSE
      - uri_extracto: file://... (obligatorio)
      - uri_contable: file://... (obligatorio)
      - days_window: int (opcional, default 5)

    Emite por SSE:
      - {type:"RUN_START", ...}
      - {type:"RESULTS_READY", payload:{summary, counts}}
    """
    try:
        form = await request.form()
        thread_id = form.get("threadId")
        # Campos históricos del frontend: extracto_original_uri / contable_original_uri
        # Nueva versión usa uri_extracto / uri_contable. Aceptamos ambos.
        uri_extracto = form.get("extracto_original_uri") or form.get("uri_extracto") or ""
        uri_contable = form.get("contable_original_uri") or form.get("uri_contable") or ""
        days_window = int(form.get("days_window") or 5)

        if not uri_extracto or not uri_contable:
            return Response({"ok": False, "message": "Faltan URIs: uri_extracto y uri_contable son obligatorios."}, status_code=400)

        if thread_id:
            asyncio.create_task(emit(thread_id, {"type": "RUN_START", "payload": {"days_window": days_window}}))

        path_extracto = _from_file_uri(uri_extracto)
        path_contable = _from_file_uri(uri_contable)

        # 1) Cargar
        df_pilaga = _load_pilaga(path_contable)
        df_banco  = _load_extracto(path_extracto)

        # 2) Conciliar
        pairs, sobrantes_p, sobrantes_b = _match_one_to_one_by_amount_and_date_window(df_pilaga, df_banco, days_window)

        # 3) Resumen
        total_p = len(df_pilaga)
        total_b = len(df_banco)
        conc_pairs = len(pairs)
        no_en_banco = len(sobrantes_p)
        no_en_pilaga = len(sobrantes_b)

        summary = {
            "movimientos_pilaga": total_p,
            "movimientos_banco": total_b,
            "conciliados_pares": conc_pairs,
            "no_en_banco": no_en_banco,    # están en PILAGA pero no en el banco
            "no_en_pilaga": no_en_pilaga,  # están en banco pero no en PILAGA
            "days_window": days_window,
        }

        if thread_id:
            asyncio.create_task(emit(thread_id, {
                "type": "RESULTS_READY",
                "payload": {
                    "summary": summary,
                    # si querés, podés agregar muestras (primeros N) para UI:
                    # "sample_no_en_banco": sobrantes_p.head(10).to_dict(orient="records"),
                    # "sample_no_en_pilaga": sobrantes_b.head(10).to_dict(orient="records"),
                }
            }))

        return Response({"ok": True, "summary": summary}, status_code=200)

    except Exception as e:
        tb = traceback.format_exc(limit=12)
        print("[reconcile_start] ERROR:", type(e).__name__, str(e), flush=True)
        print(tb, flush=True)
        try:
            form = await request.form()
            thread_id = form.get("threadId")
            if thread_id:
                asyncio.create_task(emit(thread_id, {
                    "type": "TOAST", "level": "error",
                    "message": f"Reconcile error: {type(e).__name__}: {e}"
                }))
        except Exception:
            pass
        return Response({"ok": False, "message": "Error interno en conciliación", "error": f"{type(e).__name__}: {e}", "trace": tb}, status_code=500)
